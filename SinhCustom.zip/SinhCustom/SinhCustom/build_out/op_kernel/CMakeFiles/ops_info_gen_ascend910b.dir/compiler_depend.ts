# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for ops_info_gen_ascend910b.
